# Utepils - Team 2 - IN2000

Hei!
Før du starter prosjektet er det et par ting som kan gå galt hvis du ikke har riktig!

* I filen `local.properties` må du sjekke om _sdk.dir_ peker på din SDK. Pathen er litt forskjellig fra hva slags maskin du har. Her er to eksempler:
1. `sdk.dir=C\:\\Users\\---\\AppData\\Local\\Android\\Sdk`
2. `sdk.dir=/Users/---/Library/Android/sdk`
(Har også erstattet brukernavn med "---")
Du har mest sannsynlig fått denne i zip-en: `sdk.dir=C\:\\Users\\KoLiMi\\AppData\\Local\\Android\\Sdk`


* Dobbelsjekk om du har riktig API-nøkkel! I filen `local.properties` finner du `MAPS_API_KEY`.
Her er nøkkelen som gjelder: `AIzaSyD50f9nWYkwCP5CHdYIBIPzkf_VMvScI0Y`

Håper dette hjalp! God fornøyelse

*Team 2*









