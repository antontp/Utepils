package com.example.utepils.ui.theme

import androidx.compose.ui.graphics.Color


// Utepils farger

val DarkSeaGreen = Color(0xFF92AD89)
val NavajoWhite = Color(0xFFF6D79A)
val FloralWhite = Color(0xFFFBF8F1)
val FloralWhiteShadow = Color(0xFFE2E0DA)
val KombuGreen = Color(0xFF273C2C)
val BlackChocolate = Color(0xFF000000)
val White = Color(0xFFFFFFFF)
