package com.example.utepils.model

data class Timesery(
    val `data`: Data,
    val time: String
)