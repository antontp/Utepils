package com.example.utepils.model.places

data class Viewport(
    val northeast: Northeast,
    val southwest: Southwest
)