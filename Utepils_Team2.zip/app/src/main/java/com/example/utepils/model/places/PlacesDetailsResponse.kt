package com.example.utepils.model.places

data class PlacesDetailsResponse(
    val result: Place)