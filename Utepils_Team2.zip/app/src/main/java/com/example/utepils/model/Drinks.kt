package com.example.utepils.model

data class Drinks(val drinks: List<Drink>)