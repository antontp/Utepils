package com.example.utepils.model.places

data class Location(
    val lat: Double,
    val lng: Double
)