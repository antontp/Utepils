package com.example.utepils.model.places

data class Geometry(
    val location: Location,
    val viewport: Viewport
)