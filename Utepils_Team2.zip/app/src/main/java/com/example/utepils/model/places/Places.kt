package com.example.utepils.model.places

class Places(
    val results: List<Place>
)
