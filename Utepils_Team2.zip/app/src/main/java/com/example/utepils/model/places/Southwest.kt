package com.example.utepils.model.places

data class Southwest(
    val lat: Double,
    val lng: Double
)