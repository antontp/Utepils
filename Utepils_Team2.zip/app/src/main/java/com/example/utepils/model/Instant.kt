package com.example.utepils.model

data class Instant(
    val details: Details
)