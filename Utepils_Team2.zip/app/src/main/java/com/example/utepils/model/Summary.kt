package com.example.utepils.model

data class Summary(
    val symbol_code: String
)