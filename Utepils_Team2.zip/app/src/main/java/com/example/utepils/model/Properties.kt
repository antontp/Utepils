package com.example.utepils.model

data class Properties(
    val meta: Meta,
    val timeseries: List<Timesery>
)