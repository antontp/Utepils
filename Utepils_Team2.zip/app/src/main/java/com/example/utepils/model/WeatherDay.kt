package com.example.utepils.model

data class WeatherDay(
    val times: List<Timesery>
)
