package com.example.utepils.model

data class Geometry(
    val coordinates: List<Double>
)