package com.example.utepils.model.places

data class PlusCode(
    val compound_code: String,
    val global_code: String
)