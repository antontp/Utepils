package com.example.utepils.model

data class NextHour (
    val details: DetailsHour,
    val summary: Summary,
)



