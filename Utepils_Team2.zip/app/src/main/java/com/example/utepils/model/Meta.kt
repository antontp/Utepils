package com.example.utepils.model

data class Meta(
    val units: Units,
    val updated_at: String
)