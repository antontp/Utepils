package com.example.utepils.model

data class WeatherData(
    val geometry: Geometry,
    val properties: Properties
    //val type: String
)